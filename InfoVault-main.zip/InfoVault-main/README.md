# InfoVault
InfoVault is a website written in Django to provide the information about the employees in your company.

<p align = "center">
  <img width="1000" alt="webui" src="https://github.com/Zaque-69/Short-Scripts/blob/main/ss/ss.png">
</p>

# Installation 
```
  {  package manager } python3
   pip install django && pip install pillow
```

# Nix 
```
  nix-shell
```

# Run the server 
```
  python manage.pt runserver
```
