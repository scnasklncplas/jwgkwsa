document.getElementById("full").style.height = window.innerHeight - 50 + "px";
console.log(window.innerHeight + "px");