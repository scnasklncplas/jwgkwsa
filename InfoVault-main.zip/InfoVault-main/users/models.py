from django.db import models
from django.utils import timezone

# Create your models here.
class Info(models.Model) : 
    first_name = models.TextField( blank=True, null=True )
    last_name = models.TextField( blank=True, null=True ) 
    birth_date = models.TextField( blank=True, null=True )
    phone_number = models.TextField( blank=True, null=True )
    mother = models.TextField( blank=True, null=True )
    father = models.TextField( blank=True, null=True ) 
    siblings = models.TextField( blank=True, null=True )
    gmail = models.TextField( blank=True, null=True ) 
    address = models.TextField( blank=True, null=True ) 
    cnp = models.TextField( blank=True, null=True ) 
    wifi = models.TextField( blank=True, null=True ) 
    insta = models.TextField( blank=True, null=True )
    facebook = models.TextField( blank=True, null=True )
    myfitnesspal = models.TextField( blank=True, null=True )
    netflix = models.TextField( blank = True, null = True )
    spotify = models.TextField( blank = True, null = True )
    snapchat = models.TextField( blank = True, null = True )
    reddit = models.TextField( blank = True, null = True )
    discord = models.TextField( blank = True, null = True )
    github = models.TextField( blank = True, null = True )
    x = models.TextField( blank = True, null = True )
    tiktok = models.TextField( blank = True, null = True )
    twich = models.TextField( blank = True, null = True )
    steam = models.TextField( blank = True, null = True )
    epic_games = models.TextField( blank = True, null = True )
    youtube = models.TextField( blank = True, null = True )
    pluxee = models.TextField( blank=True, null=True )
    date_posted = models.DateTimeField( default=timezone.now )
    icon = models.ImageField( blank = True, null = True, upload_to = 'Icnos' )

    def __str__(self):
        return self.first_name + " " + self.last_name