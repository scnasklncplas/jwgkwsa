from django.urls import path
from . import views
from .views import InfoDetailView

urlpatterns = [
    path('', views.main_page, name = "main_page"),
    path('user/<pk>/', InfoDetailView.as_view(), name = 'info-detail'),
]