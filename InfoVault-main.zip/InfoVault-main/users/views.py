from django.shortcuts import render
from .models import Info
from django.views.generic import DetailView

def main_page(request) : 
    return render(request, 'index.html', {
        "infos" : Info.objects.all().order_by('-date_posted')
    })

class InfoDetailView(DetailView):
    model = Info
    template_name = 'user_detail.html'
